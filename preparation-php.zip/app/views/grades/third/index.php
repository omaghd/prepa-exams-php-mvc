    <?php
    ?>

    <div class="page-wrap d-flex flex-row align-items-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-12 text-center">
                    <div class="display-4">3ème Année</div>
                    <div class="btn-group" role="group">
                        <a href="<?= URLROOT . '/grade/third/s1' ?>" class="btn btn-info btn-lg text-uppercase">S1</a>
                        <a href="<?= URLROOT . '/grade/third/s2' ?>" class="btn btn-info btn-lg text-uppercase">S2</a>
                    </div>
                </div>
            </div>
        </div>
    </div>