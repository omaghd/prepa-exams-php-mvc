    <?php
    ?>

    <div class="page-wrap d-flex flex-row align-items-center">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-12 text-center">
                    <div class="display-2 mb-2">404 Page!</div>
                    <a href="<?= URLROOT ?>" class="btn btn-link"><i class="fas fa-backward mr-2"></i>Retour à la page d'accueil</a>
                </div>
            </div>
        </div>
    </div>