<?php

// Require the config file
require_once 'config/config.php';

// Require libraries from folder libs
require_once LIB . 'Core.php';
require_once LIB . 'Controller.php';
require_once LIB . 'Database.php';

// Instantiate core class
$init = new Core();
