<?php

class Grade
{
}
